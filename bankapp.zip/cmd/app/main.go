package main

import "bankapp/internal/server"

func main() {
	server.Start()
}
