package server

import (
	"bankapp/internal/handlers"
	"bankapp/internal/middleware"

	"github.com/gin-gonic/gin"
)

func setupRouter() *gin.Engine {
	r := gin.Default()
	r.POST("/register", handlers.Register)
	r.POST("/login", handlers.Login)

	auth := r.Group("/api")
	auth.Use(middleware.JWTAuth())
	{
		auth.GET("/profile", handlers.Profile)
		auth.POST("/deposit", handlers.Deposit)
		auth.POST("/withdraw", handlers.Withdraw)
		auth.GET("/balance", handlers.GetBalance)
	}

	return r
}
