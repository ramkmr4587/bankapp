package handlers

import (
	"bankapp/pkg/model"
	"net/http"

	"github.com/gin-gonic/gin"
)

func Deposit(c *gin.Context) {
	model.HandleDeposit(c)
}

func Withdraw(c *gin.Context) {
	model.HandleWithdraw(c)
}

func GetBalance(c *gin.Context) {
	model.HandleGetBalance(c)
}

func Profile(c *gin.Context) {
	uid := c.MustGet("user_id")
	c.JSON(http.StatusOK, gin.H{"user_id": uid})
}
