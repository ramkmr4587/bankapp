package model

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

type TxRequest struct {
	Amount float64 `json:"amount" binding:"required,gt=0"`
}

var balances = map[string]float64{}

func HandleDeposit(c *gin.Context) {
	var req TxRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	uid := c.MustGet("user_id").(string)
	balances[uid] += req.Amount
	c.JSON(http.StatusOK, gin.H{"user_id": uid, "balance": balances[uid]})
}

func HandleWithdraw(c *gin.Context) {
	var req TxRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	uid := c.MustGet("user_id").(string)
	if balances[uid] < req.Amount {
		c.JSON(http.StatusBadRequest, gin.H{"error": "insufficient funds"})
		return
	}
	balances[uid] -= req.Amount
	c.JSON(http.StatusOK, gin.H{"user_id": uid, "balance": balances[uid]})
}

func HandleGetBalance(c *gin.Context) {
	uid := c.MustGet("user_id").(string)
	c.JSON(http.StatusOK, gin.H{"user_id": uid, "balance": balances[uid]})
}
